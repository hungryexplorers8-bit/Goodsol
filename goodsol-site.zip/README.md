# $GOODSOL – Meme Coin for Love ❤️

[![Netlify Status](https://api.netlify.com/api/v1/badges/YOUR-NETLIFY-SITE-ID/deploy-status)](https://app.netlify.com/sites/YOUR-SITE-NAME/deploys)

🌐 **Live site:** [https://YOUR-SITE-NAME.netlify.app](https://YOUR-SITE-NAME.netlify.app)

$GOODSOL is more than a coin – it’s a movement about giving back, spreading love, and building community in dark times.

---

## 🌍 Links
- Telegram: [Join us](https://t.me/DEEGENKINGCRYPTOFAM)
- Discord: [Join the fam](https://discord.gg/XgXNqyt7)

---

## 🚀 Deploy
This site is built with **Vite + React + Tailwind** and auto-deploys to **Netlify** on each push to `main`.
