import GoodSolLanding from "./GoodSolLanding";

export default function App() {
  return <GoodSolLanding />;
}